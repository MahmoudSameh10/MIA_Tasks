#include <iostream>
#include <string>
/************************************************Define the Weapon and Shield Classes***********************************************/
class Weapon {
public:
    std::string name;
    int energyCost;
    int damage;
    int uses;

    Weapon(std::string n, int e, int d, int u) : name(n), energyCost(e), damage(d), uses(u) {}

    void useWeapon() {
        if (uses > 0) {
            --uses;
        }
    }

    bool isAvailable() const {
        return uses != 0;
    }
};

class Shield {
public:
    std::string name;
    int energyCost;
    float damageReduction;
    int uses;

    Shield(std::string n, int e, float d, int u) : name(n), energyCost(e), damageReduction(d), uses(u) {}

    void useShield() {
        if (uses > 0) {
            --uses;
        }
    }

    bool isAvailable() const {
        return uses != 0;
    }
};

/***********************************************define the character class*******************************************************/
class Character {
public:
    std::string name;
    int health;
    int energy;
    Weapon* currentWeapon;
    Shield* currentShield;

    Character(std::string n, int h, int e) : name(n), health(h), energy(e), currentWeapon(nullptr), currentShield(nullptr) {}

    void attack(Character& opponent) {
        if (currentWeapon->isAvailable() && energy >= currentWeapon->energyCost) {
            currentWeapon->useWeapon();
            energy -= currentWeapon->energyCost;

            int damage = currentWeapon->damage;

            if (opponent.currentShield->isAvailable() && opponent.energy >= opponent.currentShield->energyCost) {
                opponent.currentShield->useShield();
                opponent.energy -= opponent.currentShield->energyCost;
                damage = static_cast<int>(damage * (1 - opponent.currentShield->damageReduction));
            }

            opponent.health -= damage;
            if (opponent.health < 0) opponent.health = 0;

            printAttack(opponent, damage);
        }
    }

    bool isAlive() const {
        return health > 0;
    }

    void printAttack(const Character& opponent, int damage) const {
        std::cout << name << " attacks " << opponent.name << " using " << currentWeapon->name << "\n";
        std::cout << opponent.name << " uses " << opponent.currentShield->name << "\n";
        std::cout << opponent.name << " takes " << damage << " damage, remaining health: " << opponent.health << "\n\n";
    }
};
void fight(Character& batman, Character& joker) {
    while (batman.isAlive() && joker.isAlive()) {
        batman.attack(joker);
        if (!joker.isAlive()) break;

        joker.attack(batman);
    }

    if (batman.isAlive()) {
        std::cout << "Batman wins!\n";
    } else {
        std::cout << "Joker wins!\n";
    }
}
/********************************Implement the fight logic************************************************/
int main() {
    // Batman_gadgets
    Weapon batarang("Batarang", 50, 11, 100);
    Weapon grappleGun("Grapple Gun", 88, 18, 5);
    Shield capeGlide("Cape Glide", 20, 0.4, 100);

    // Joker_gadgets
    Weapon joyBuzzer("Joy Buzzer", 40, 8, 100);
    Shield trickShield("Trick Shield", 15, 0.32, 100);

    Character batman("Batman", 100, 500);
    Character joker("Joker", 100, 500);

    batman.currentWeapon = &batarang;
    batman.currentShield = &capeGlide;

    joker.currentWeapon = &joyBuzzer;
    joker.currentShield = &trickShield;

    // Start the fight
    fight(batman, joker);

    return 0;
}
